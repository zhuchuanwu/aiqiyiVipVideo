import { appStore } from "./app.store";
import { dropDownStore } from "./dropdown.store";
const mainStore = {
  dropDownStore,
  appStore,
};

export default mainStore;
